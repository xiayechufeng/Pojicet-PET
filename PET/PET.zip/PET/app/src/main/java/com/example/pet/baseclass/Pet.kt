package com.example.pet.baseclass

import android.net.Uri
import java.net.URI

// TODO: 2021/8/3 宠物类待完善
class Pet(val PName:String,PId : Int,val ImageID : Int) {

}